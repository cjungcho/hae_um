//
//  ViewController.swift
//  seorin
//
//  Created by Catherine on 8/21/20.
//  Copyright © 2020 cat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

