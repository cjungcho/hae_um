//
//  ViewController.swift
//  dailynote
//
//  Created by Catherine on 8/7/20.
//  Copyright © 2020 cat. All rights reserved.
//
import FSCalendar
import UIKit

class ViewController: UIViewController{
    
    @IBOutlet weak var Calendar: FSCalendar!
    
    @IBAction func SettingButton(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(identifier: "setting_vc") as! SettingViewController
        present(vc, animated: true)
    }
    override func viewDidLoad(){
        super.viewDidLoad()
    }
    

}
