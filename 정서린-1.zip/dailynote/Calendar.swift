import FSCalendar
import UIKit


class Calendar: UIViewController, FSCalendarDelegate, FSCalendarDataSource {
    
   var datesWithEvent = ["2020-08-03", "2015-10-06", "2015-10-12", "2015-10-25"]

    fileprivate lazy var dateFormatter2: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    }()
    
    var writtendays : Array = [String]()
    
      @IBOutlet weak var Calendar: FSCalendar!
      fileprivate weak var eventLabel: UILabel!
    
    
    var filldays = [String]() //일기 쓴날
  
    
    @IBAction func SettingButton(_ sender: UIButton) {
        let vc = storyboard?.instantiateViewController(identifier: "setting_vc") as! Setting
        present(vc, animated: true)
    }
    override func viewDidLoad(){
        super.viewDidLoad()
        Calendar.clipsToBounds = true //달력 구분 선 제거
        Calendar.delegate = self
        Calendar.dataSource = self
    }
    
    func calendar(calendar: FSCalendar, didSelectDate date: NSDate) {
            super.viewDidLoad()
        }
    
    func calendar(_ calendar: FSCalendar, numberOfEventsFor date: Date) -> Int {

         let dateString = self.dateFormatter2.string(from: date)

         if self.datesWithEvent.contains(dateString) {
             return 1
         }

         return 0
     }
//    func calendar(_ calendar: FSCalendar, appearance: FSCalendarAppearance, eventDefaultColorsFor date: Date) -> [UIColor]? {
//        if self.gregorian.isDateInToday(date) {
//              return [UIColor.orange]
//          }
//          return [appearance.eventDefaultColor]
//      }
      
}
    
