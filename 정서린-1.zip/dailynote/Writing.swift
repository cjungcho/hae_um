//
//  Writing.swift
//  dailynote
//
//  Created by Catherine on 8/20/20.
//  Copyright © 2020 cat. All rights reserved.
//

import UIKit

class Writing: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}
extension Writing
{
    static let newMemoDidInsert = Notification.Name(rawValue: "newMemoDidInsert")
    static let memoDidChange = Notification.Name(rawValue: "memoDidChange")
}
